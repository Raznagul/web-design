<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'gui', 'deng', 'zhi', 'xu', 'yi', 'hua', 'xi', 'kui', 'rao', 'xi', 'yan', 'chan', 'jiao', 'mei', 'fan', 'fan',
  0x10 => 'xian', 'yi', 'hui', 'jiao', 'fu', 'shi', 'bi', 'shan', 'sui', 'qiang', 'lian', 'huan', 'xin', 'niao', 'dong', 'yi',
  0x20 => 'can', 'ai', 'niang', 'ning', 'ma', 'tiao', 'chou', 'jin', 'ci', 'yu', 'pin', 'rong', 'ru', 'nai', 'yan', 'tai',
  0x30 => 'ying', 'can', 'niao', 'yue', 'ying', 'mian', 'bi', 'ma', 'shen', 'xing', 'ni', 'du', 'liu', 'yuan', 'lan', 'yan',
  0x40 => 'shuang', 'ling', 'jiao', 'niang', 'lan', 'qian', 'ying', 'shuang', 'hui', 'quan', 'mi', 'li', 'luan', 'yan', 'zhu', 'lan',
  0x50 => 'zi', 'jie', 'jue', 'jue', 'kong', 'yun', 'ma', 'zi', 'cun', 'sun', 'fu', 'bei', 'zi', 'xiao', 'xin', 'meng',
  0x60 => 'si', 'tai', 'bao', 'ji', 'gu', 'nu', 'xue', 'you', 'zhuan', 'hai', 'luan', 'sun', 'nao', 'mie', 'cong', 'qian',
  0x70 => 'shu', 'can', 'ya', 'zi', 'ni', 'fu', 'zi', 'li', 'xue', 'bo', 'ru', 'nai', 'nie', 'nie', 'ying', 'luan',
  0x80 => 'mian', 'ning', 'rong', 'ta', 'gui', 'zhai', 'qiong', 'yu', 'shou', 'an', 'tu', 'song', 'wan', 'rou', 'yao', 'hong',
  0x90 => 'yi', 'jing', 'zhun', 'mi', 'zhu', 'dang', 'hong', 'zong', 'guan', 'zhou', 'ding', 'wan', 'yi', 'bao', 'shi', 'shi',
  0xA0 => 'chong', 'shen', 'ke', 'xuan', 'shi', 'you', 'huan', 'yi', 'tiao', 'shi', 'xian', 'gong', 'cheng', 'qun', 'gong', 'xiao',
  0xB0 => 'zai', 'zha', 'bao', 'hai', 'yan', 'xiao', 'jia', 'shen', 'chen', 'rong', 'huang', 'mi', 'kou', 'kuan', 'bin', 'su',
  0xC0 => 'cai', 'zan', 'ji', 'yuan', 'ji', 'yin', 'mi', 'kou', 'qing', 'que', 'zhen', 'jian', 'fu', 'ning', 'bing', 'huan',
  0xD0 => 'mei', 'qin', 'han', 'yu', 'shi', 'ning', 'jin', 'ning', 'zhi', 'yu', 'bao', 'kuan', 'ning', 'qin', 'mo', 'cha',
  0xE0 => 'ju', 'gua', 'qin', 'hu', 'wu', 'liao', 'shi', 'ning', 'zhai', 'shen', 'wei', 'xie', 'kuan', 'hui', 'liao', 'jun',
  0xF0 => 'huan', 'yi', 'yi', 'bao', 'qin', 'chong', 'bao', 'feng', 'cun', 'dui', 'si', 'xun', 'dao', 'lu', 'dui', 'shou',
];
